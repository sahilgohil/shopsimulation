/**
 * The Assessment1V2 class is the main class for the simulation program. It sets up the simulation with an instance of the ShopModel
 * and a list of events, initializes the simulator, runs the simulation for a specified time period, and prints the statistics of the
 * simulation to the console and a text file.
 *
 * The main method initializes a ShopModel with a capacity of 8 and creates an instance of the Simulator. It then creates an empty
 * ArrayList of events and adds an ArrivalEvent with time 0 to the list. The simulator is initialized with the eventQueue, which
 * contains only the ArrivalEvent. The simulation is run for 20 time units. After the simulation has ended, the program prints the
 * number of customers served and lost to the console. It then creates a statistics.txt file and writes the number of customers
 * served, the number of customers lost, and the groups and logs of the simulation to the file using the Formatter class.
 *
 * @author Sahil Natvarlal Gohil
 */

package com.mycompany.assessment1v2;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Formatter;
/**
 *
 * @author sahil
 */
public class Assessment1V2 {public static void main(String[] args) {

        ShopModel shopModel = new ShopModel(8);
        Simulator simulator = new Simulator(shopModel);
        ArrayList<Event> eventQueue = new ArrayList<>();
        eventQueue.add(new ArrivalEvent(0));

        simulator.initialize(eventQueue);
        simulator.run(20);

        // Print statistics to console
        System.out.println();
        System.out.println();
       

        // Write statistics to file
        File file = new File("statistics.txt");
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("Number of customers served: %d%n%n", shopModel.getNumberServed()));
        sb.append(String.format("Number of customers that were lost: %d%n%n", shopModel.getLostBusiness()));

        try ( Formatter f = new Formatter(file)) {
            f.format(String.valueOf(sb));
            shopModel.showGroups(f);
            shopModel.showLog(f);

        } catch (FileNotFoundException e) {
            System.out.println("File is not found");
            e.printStackTrace();
        }

    }
}
