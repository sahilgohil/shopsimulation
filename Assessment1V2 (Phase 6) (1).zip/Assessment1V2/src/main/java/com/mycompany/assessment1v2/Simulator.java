/**
 * The Simulator class is responsible for simulating the shop model by processing events based on their timestamps.
 * It implements the IScheduler interface which specifies methods for scheduling events in the simulation.
 *
 * @author Sahil Natvarlal Gohil
 */

package com.mycompany.assessment1v2;

import java.util.ArrayList;

public class Simulator implements IScheduler{

    private ArrayList<Event> events;
    private int clock;
    private ShopModel model;

    /**
     * Constructor for the Simulator class
     *
     * @param m the ShopModel object that is to be simulated
     */
    public Simulator(ShopModel m)
    {
        this.model = m;
    }

    /**
     * Initializes the events list with the given ArrayList of events
     *
     * @param events an ArrayList of events to be scheduled in the simulation
     */
    public void initialize(ArrayList<Event> events)
    {
        this.events = events;
    }

    /**
     * Runs the simulation until the given stop time is reached
     *
     * @param stopTime the time at which the simulation should stop
     */
    public void run(int stopTime)
    {
        if(events == null || events.isEmpty())
        {
            return;
        }
        Event e = events.remove(0);
        clock = e.getTime();
        while(clock <= stopTime)
        {
            e.process(model, this);
            if(events == null || events.isEmpty())
            {
                break;
            }
            e = events.remove(0);
            clock = e.getTime();
        }
    }

    /**
     * Adds the given event to the events list in the correct order based on the timestamp of the event
     *
     * @param event the event to be scheduled in the simulation
     */
    public void schedule(Event event)
    {
        // if the list is empty
        if(events == null || events.isEmpty())
        {
            events.add(event);
            return;
        }
        // if the list has only one element
        if(events.size() == 1)
        {
            if(events.get(0).getTime()>event.getTime())
            {
                events.add(0, event);
                return;
            }
            else
            {
                events.add(event);
                return;
            }
        }

        int index = -1;
        for(Event e: events)
        {
            if(e.getTime() > event.getTime())
            {
                index = events.indexOf(e);
                break;
            }
        }
        // if the event has the greatest time in all the element events
        if(index == -1)
        {
            events.add(event);
            return;
        }

        // if above all the conditions are false
        events.add(index, event);
    }
}