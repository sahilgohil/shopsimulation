/**
 * This class represents a collect items event in the simulation.
 * When a customer group arrives at the store, they collect their items in this event.
 * The event schedules the next PayEvent in the simulation.
 *
 * @author Sahil Natvarlal Gohil
 *
 */
package com.mycompany.assessment1v2;
public class CollectItemsEvent extends Event {

    private CustomerGroup group;

    /**
     * Constructor for CollectItemsEvent class.
     *
     * @param time the time of the event
     * @param g the customer group associated with the event
     */
    public CollectItemsEvent(int time, CustomerGroup g) {
        super(time);
        this.group = g;
    }

    /**
     * This method processes the collect items event. It calls the collectItems
     * method of ShopModel with the time and the customer group, and schedules
     * the next PayEvent with the scheduler.
     *
     * @param shopModel the shop model used for the simulation
     * @param scheduler the scheduler used for the simulation
     */
    @Override
    public void process(ShopModel shopModel, IScheduler scheduler) {
        shopModel.collectItems(super.getTime(), group);
        scheduler.schedule(new PayEvent(super.getTime() + 4, group));
    }

}
