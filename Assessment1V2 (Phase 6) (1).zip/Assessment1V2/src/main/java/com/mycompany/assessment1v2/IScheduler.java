/**
 * The IScheduler interface represents a scheduler that schedules events.
 * Any class that implements this interface must implement the schedule method.
 *
 * @author Sahil Natvarlal Gohil
 */
package com.mycompany.assessment1v2;

public interface IScheduler {

    /**
     * Schedules an event to occur at a certain time.
     *
     * @param e the event to be scheduled
     */
    public void schedule(Event e);
}
