package com.mycompany.assessment1v2;

/**
 * PayEvent class represents an event in which a customer group pays for their items.
 * It extends the Event class and implements the process method.
 *
 * @author Sahil
 *
 */
public class PayEvent extends Event {

    private CustomerGroup group;

    /**
     * Constructor for PayEvent
     *
     * @param time The time when this event occurs
     * @param g The customer group associated with this event
     */
    public PayEvent(int time, CustomerGroup g) {
        super(time);
        this.group = g;
    }

    /**
     * This method processes the PayEvent. It calls the pay method of the
     * ShopModel class and schedules a new LeaveEvent for the customer group.
     *
     * @param shopModel The ShopModel object
     * @param scheduler The scheduler object
     */
    @Override
    public void process(ShopModel shopModel, IScheduler scheduler) {
        shopModel.pay(super.getTime(), group);
        scheduler.schedule(new LeaveEvent(super.getTime() + 1, group));
    }

}
