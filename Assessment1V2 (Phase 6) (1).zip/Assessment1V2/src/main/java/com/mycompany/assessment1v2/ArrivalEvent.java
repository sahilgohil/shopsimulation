/**
 * The ArrivalEvent class is a subclass of the Event class and represents the arrival of a customer group.
 * It processes the arrival event by creating a new CustomerGroup object, adding it to the ShopModel object,
 * logging the group, and scheduling a CollectItemsEvent object to occur after a random amount of time.
 * Additionally, it schedules the next ArrivalEvent to occur after a fixed amount of time.
 *
 * @author Sahil Natvarlal Gohil
 */
package com.mycompany.assessment1v2;

public class ArrivalEvent extends Event {

    private int groupLowerBound; // lower bound for group size
    private int groupGeneratorBound; // upper bound for group size
    private int collectTimeLowerBound; // lower bound for time to collect items
    private int collectTimeGeneratorBound; // upper bound for time to collect items

    /**
     * Constructs an ArrivalEvent object with the given time.
     *
     * @param time the time of the arrival event
     */
    public ArrivalEvent(int time) {
        super(time);
    }

    /**
     * Processes the arrival event by generating a new CustomerGroup object with
     * a random size and arrival time, adding it to the ShopModel object,
     * logging the group, and scheduling a CollectItemsEvent object to occur
     * after a random amount of time. Additionally, it schedules the next
     * ArrivalEvent to occur after a fixed amount of time.
     *
     * @param shopModel the ShopModel object for the simulation
     * @param scheduler the IScheduler object used to schedule events
     */
    public void process(ShopModel shopModel, IScheduler scheduler) {
        int size = shopModel.getNumGroups();
        int id = shopModel.getNextId();

        groupLowerBound = 1;
        groupGeneratorBound = 3;
        collectTimeGeneratorBound = 8;
        collectTimeLowerBound = 3;
        int groupNum = super.getGenerator().nextInt(groupGeneratorBound) + groupLowerBound;
        int collectionTime = super.getGenerator().nextInt(collectTimeGeneratorBound) + collectTimeLowerBound;
        if (id == 0) {
            System.out.println("Simulation Trace:");
            System.out.println("==============");
        }
        CustomerGroup arrivalGroup = new CustomerGroup(id, groupNum, super.getTime());
        System.out.println("t = " + arrivalGroup.getArrivalTime() + ": Group " + arrivalGroup.getId() + " <" + arrivalGroup.getNumberInGroup() + " people> arrived");

        shopModel.addGroup(arrivalGroup);
        shopModel.logGroup(arrivalGroup);

        if (shopModel.getNumGroups() > size) {
            scheduler.schedule(new CollectItemsEvent(super.getTime() + collectionTime, arrivalGroup));
        }

        scheduler.schedule(new ArrivalEvent(super.getTime() + 2));
    }

}
