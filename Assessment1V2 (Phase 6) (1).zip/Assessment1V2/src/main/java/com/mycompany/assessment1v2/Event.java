/**
 * This abstract class represents an event in a simulation program. It contains a time attribute and a process method that must
 * be implemented by its subclasses.
 *
 * It also contains a static Random generator that can be used by any subclass to generate random numbers.
 *
 * @author Sahil Natvarlal Gohil
 */
package com.mycompany.assessment1v2;

import java.util.Random;

public abstract class Event {

    private int time;

    /**
     * Constructs an Event object with the specified time.
     *
     * @param time the time of the event
     */
    public Event(int time) {
        this.time = time;
    }

    /**
     * Returns the time of the event.
     *
     * @return the time of the event
     */
    public int getTime() {
        return time;
    }

    /**
     * Returns the static Random generator that can be used by any subclass to
     * generate random numbers.
     *
     * @return the static Random generator
     */
    public Random getGenerator() {
        return generator;
    }

    /**
     * This method must be implemented by any subclass of Event. It processes
     * the event and modifies the state of the simulation as needed.
     *
     * @param shopModel the ShopModel object representing the state of the
     * simulation
     * @param scheduler the IScheduler object representing the scheduler used to
     * schedule events in the simulation
     */
    public abstract void process(ShopModel shopModel, IScheduler scheduler);

    /**
     * A static Random object that can be used by any subclass to generate
     * random numbers.
     */
    static Random generator = new Random(1);

}
