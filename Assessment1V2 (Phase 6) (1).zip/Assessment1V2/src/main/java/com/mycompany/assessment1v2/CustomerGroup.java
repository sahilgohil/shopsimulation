/**
 * This class represents a customer group in the simulation.
 * A customer group has an id, number of people in the group, and arrival time.
 * It has methods to retrieve these values and a toString method to represent the group as a string.
 *
 * @author Sahil Natvarlal Gohil
 *
 */
package com.mycompany.assessment1v2;


public class CustomerGroup {

    private int id;
    private int numberInGroup;
    private int arrivalTime;

    /**
     * Constructor for CustomerGroup class.
     *
     * @param id the id of the customer group
     * @param number the number of people in the group
     * @param time the arrival time of the group
     */
    public CustomerGroup(int id, int number, int time) {
        this.id = id;
        this.numberInGroup = number;
        this.arrivalTime = time;
    }

    /**
     * Getter method for the id of the customer group.
     *
     * @return the id of the customer group
     */
    public int getId() {
        return id;
    }

    /**
     * Getter method for the number of people in the customer group.
     *
     * @return the number of people in the customer group
     */
    public int getNumberInGroup() {
        return numberInGroup;
    }

    /**
     * Getter method for the arrival time of the customer group.
     *
     * @return the arrival time of the customer group
     */
    public int getArrivalTime() {
        return arrivalTime;
    }

    /**
     * Returns a string representation of the customer group.
     *
     * @return a string representation of the customer group
     */
    @Override
    public String toString() {
        return String.format("Group %d (%d people) arrived at t = %d", getId(), getNumberInGroup(), getArrivalTime());
    }

}
