
package com.mycompany.assessment1v2;
/**
 * A class that represents a leave event for a customer group.
 *
 * When a leave event is triggered, the corresponding customer group is removed from the shop model.
 *
 * @author Sahil Natvarlal Gohil
 */


public class LeaveEvent extends Event {

    private CustomerGroup group;

    /**
     * Constructs a LeaveEvent object with the given time and customer group.
     *
     * @param time the time at which the leave event is triggered
     * @param g the customer group that is leaving the shop
     */
    public LeaveEvent(int time, CustomerGroup g) {
        super(time);
        this.group = g;
    }

    /**
     * Processes the leave event by removing the corresponding customer group
     * from the shop model.
     *
     * @param shopModel the shop model to be updated
     * @param scheduler the scheduler object to schedule new events
     */
    @Override
    public void process(ShopModel shopModel, IScheduler scheduler) {
        shopModel.leave(super.getTime(), group);
    }
}
