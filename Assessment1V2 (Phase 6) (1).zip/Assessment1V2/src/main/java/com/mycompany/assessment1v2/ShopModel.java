/**
 *
 *
 * The ShopModel class represents a model of a shop that can be used to simulate customer behavior within the shop.
 * The class maintains lists of customer groups that are currently in the shop,
 * as well as customer groups that have already left. It also tracks information such as the number of
 * groups served, the number of groups turned away due to lack of space, and the total number of customers served.
 * The class provides methods for adding groups to the shop, logging customer activity,
 * and processing events such as paying and leaving the shop.
 *
 * @author Sahil Natvarlal Gohil
 */
package com.mycompany.assessment1v2;

import java.util.ArrayList;
import java.util.Formatter;

public class ShopModel {

    private ArrayList<CustomerGroup> groups = new ArrayList<>();
    private ArrayList<CustomerGroup> history = new ArrayList<>();
    private int nextID;
    private int numGroups;
    private int spaceAvailable;
    private int lostBusiness;
    private int numServed;

    /**
     * Constructs a ShopModel object with the specified maximum shop capacity.
     *
     * @param max the maximum number of customers that the shop can accommodate
     */
    public ShopModel(int max) {
        this.spaceAvailable = max;
    }

    /**
     * Adds the specified customer group to the shop if there is sufficient
     * space.
     *
     * @param g the customer group to add to the shop
     */
    public void addGroup(CustomerGroup g) {
        if (canEnter(g)) {
            spaceAvailable = spaceAvailable - g.getNumberInGroup();
            this.groups.add(g);
            numGroups++;
            System.out.println("t = " + g.getArrivalTime() + ": Group " + g.getId() + "  (" + g.getNumberInGroup() + ") enter the shop");

        } else {
            lostBusiness = lostBusiness + g.getNumberInGroup();
            System.out.println("t = " + g.getArrivalTime() + ": Group " + g.getId() + " leaves as there is insufficient room for the group");
        }

    }

    /**
     * Checks if the specified customer group can enter the shop based on the
     * available space.
     *
     * @param g the customer group to check
     * @return true if the group can enter the shop, false otherwise
     */
    private boolean canEnter(CustomerGroup g) {
        return spaceAvailable >= g.getNumberInGroup();
    }

    /**
     * Logs the specified customer group in the shop's history.
     *
     * @param g the customer group to log
     */
    public void logGroup(CustomerGroup g) {
        history.add(g);
    }

    /**
     * Returns the next available customer group ID.
     *
     * @return the next customer group ID
     */
    public int getNextId() {
        return nextID++;
    }

    /**
     * Prints a list of all customer groups currently in the shop to the
     * specified formatter.
     *
     * @param output the formatter to print to
     */
    public void showGroups(Formatter output) {
        StringBuilder sb = new StringBuilder();
        sb.append("the following groups are in the shop:\n");
        sb.append("=====================================\n");

        for (CustomerGroup g : groups) {
            sb.append(String.format("%s%n", g.toString()));
        }
        output.format(String.valueOf(sb));
    }

    /**
     * Prints a list of all customer groups visited the shop to the specified
     * formatter.
     *
     * @param output the formatter to print to
     */
    public void showLog(Formatter output) {
        StringBuilder sb = new StringBuilder();
        sb.append("\n\nthe following groups are in the history/log:\n");
        sb.append("=====================================\n");
        for (CustomerGroup g : history) {
            sb.append(String.format("%s%n", g.toString()));
        }
        output.format(String.valueOf(sb));

    }

    /**
     * Collects items for a given customer group at a specific time.
     *
     * @param time the time when the items are collected
     * @param g the customer group for which the items are being collected
     */
    public void collectItems(int time, CustomerGroup g) {
        System.out.println("t = " + time + ": Purchases collected by Group " + g.getId());
    }

    /**
     * customer pays for their collected item at a specific time.
     *
     * @param time the time when the payment occurs
     * @param g the customer group which will pay
     */
    public void pay(int time, CustomerGroup g) {
        numServed = numServed + g.getNumberInGroup();
        System.out.println("t = " + time + ": Group " + g.getId() + "  customer has paid");
    }

    /**
     * Customer group leaves the shop at a specific time.
     *
     * @param time the time when the customer group leaves the shop
     * @param g the customer group which leaves the shop
     */
    public void leave(int time, CustomerGroup g) {
        System.out.println("t = " + time + ": Group " + g.getId() + "  leaves the shop");
        groups.remove(g);
        numGroups--;
        spaceAvailable = spaceAvailable + g.getNumberInGroup();
    }

    /**
     * A method to get the number of groups that are currently in the shop.
     *
     * @return an integer representing the number of groups in the shop.
     */
    public int getNumGroups() {
        return numGroups;
    }

    /**
     * A method to get the number of potential customers who were turned away
     * due to the shop being full.
     *
     * @return an integer representing the number of potential customers who
     * left the shop without making a purchase.
     */
    public int getLostBusiness() {
        return lostBusiness;
    }

    /**
     * A method to get the number of customers who have been served so far.
     *
     * @return an integer representing the number of customers who have made a
     * purchase and left the shop.
     */
    public int getNumberServed() {
        return numServed;
    }

}
